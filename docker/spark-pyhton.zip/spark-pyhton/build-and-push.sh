#!/bin/bash

sudo docker build -t hugopascual/spark-python-bdfi . && sudo docker push hugopascual/spark-python-bdfi
